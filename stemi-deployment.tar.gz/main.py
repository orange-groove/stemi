from fastapi import FastAPI, File, UploadFile, HTTPException, BackgroundTasks
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
import os
import uuid
import asyncio
from pathlib import Path
import torch
import torchaudio
import demucs.separate
import soundfile as sf
import librosa
import numpy as np
from typing import List, Optional
import logging
from supabase_integration import SupabaseStemStorage

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="STEMI Separation Service",
    description="GPU-accelerated stem separation using Demucs",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global variables for model management
model = None
device = None
supabase_storage = None

# Initialize directories
UPLOAD_DIR = Path("/app/uploads")
OUTPUT_DIR = Path("/app/outputs")
UPLOAD_DIR.mkdir(exist_ok=True)
OUTPUT_DIR.mkdir(exist_ok=True)

@app.on_event("startup")
async def startup_event():
    """Initialize the Demucs model and Supabase storage on startup"""
    global model, device, supabase_storage
    
    try:
        # Check if CUDA is available
        if torch.cuda.is_available():
            device = torch.device("cuda")
            logger.info(f"Using GPU: {torch.cuda.get_device_name(0)}")
        else:
            device = torch.device("cpu")
            logger.info("CUDA not available, using CPU")
        
        # Demucs model will be loaded by the command-line tool
        logger.info(f"Using Demucs with device: {device}")
        logger.info("Model loaded successfully")
        
        # Initialize Supabase storage
        try:
            supabase_storage = SupabaseStemStorage()
            logger.info("Supabase storage initialized successfully")
        except Exception as e:
            logger.warning(f"Supabase storage not available: {e}")
            supabase_storage = None
        
    except Exception as e:
        logger.error(f"Failed to initialize model: {e}")
        raise e

class StemSeparationRequest:
    def __init__(self, file_path: str, stems: List[str] = None):
        self.file_path = file_path
        self.stems = stems or ["drums", "bass", "other", "vocals"]
        self.job_id = str(uuid.uuid4())

def separate_stems(file_path: str, stems: List[str] = None) -> dict:
    """
    Separate audio file into stems using Demucs
    """
    try:
        if stems is None:
            stems = ["drums", "bass", "other", "vocals"]
        
        logger.info(f"Starting stem separation for {file_path}")
        
        # Load audio file
        waveform, sample_rate = torchaudio.load(file_path)
        
        # Convert to mono if stereo
        if waveform.shape[0] > 1:
            waveform = torch.mean(waveform, dim=0, keepdim=True)
        
        # Resample if necessary (Demucs expects 44.1kHz)
        if sample_rate != 44100:
            resampler = torchaudio.transforms.Resample(sample_rate, 44100)
            waveform = resampler(waveform)
            sample_rate = 44100
        
        # Move to device
        waveform = waveform.to(device)
        
        # Use the same approach as stemi-service
        from demucs.separate import main as demucs_main
        import sys
        import tempfile
        import glob
        import shutil
        
        # Create a temporary directory for demucs output
        temp_demucs_dir = tempfile.mkdtemp()
        
        # Save original sys.argv and replace with demucs arguments
        original_argv = sys.argv.copy()
        try:
            sys.argv = [
                'demucs.separate',
                '-n', 'htdemucs_6s',
                '-d', str(device),
                '-o', temp_demucs_dir,
                str(file_path)
            ]
            
            # Run demucs
            demucs_main()
            
            # Find the output files
            # Look for the demucs output directory - htdemucs_6s creates nested structure
            song_dirs = glob.glob(os.path.join(temp_demucs_dir, 'htdemucs_6s', '*'))
            demucs_output_dirs = []
            
            for song_dir in song_dirs:
                if os.path.isdir(song_dir):
                    demucs_output_dirs.append(song_dir)
                    break
            
            if not demucs_output_dirs:
                # Fallback to other model patterns
                demucs_output_dirs = glob.glob(os.path.join(temp_demucs_dir, 'htdemucs', '*'))
            
            logger.info(f"Looking for demucs output in: {temp_demucs_dir}")
            logger.info(f"Found demucs output dirs: {demucs_output_dirs}")
            
            if demucs_output_dirs:
                demucs_output_dir = demucs_output_dirs[0]
                logger.info(f"Using demucs output dir: {demucs_output_dir}")
                
                # List all files in the demucs output directory
                all_files = os.listdir(demucs_output_dir)
                logger.info(f"All files in demucs output: {all_files}")
                
                # Copy the stem files to our output directory
                stem_files = glob.glob(os.path.join(demucs_output_dir, '*.wav'))
                logger.info(f"Found demucs output files: {stem_files}")
                
                stem_names = ['vocals', 'bass', 'drums', 'guitar', 'piano', 'other']
                separated = []
                
                for i, stem_file in enumerate(stem_files):
                    if i < len(stem_names):
                        # Load the stem audio
                        stem_audio, sr = torchaudio.load(stem_file)
                        separated.append(stem_audio)
                        logger.info(f"Loaded stem {stem_names[i]} from {stem_file}")
                    else:
                        logger.warning(f"Extra stem file found: {stem_file}")
                
                # Clean up
                shutil.rmtree(temp_demucs_dir)
            else:
                raise ValueError("No demucs output found")
                
        finally:
            # Restore original sys.argv
            sys.argv = original_argv
        
        # Create output directory for this job
        job_id = str(uuid.uuid4())
        job_dir = OUTPUT_DIR / job_id
        job_dir.mkdir(exist_ok=True)
        
        # Save separated stems
        output_files = {}
        for i, stem in enumerate(stems):
            if i < len(separated):
                stem_audio = separated[i].cpu().numpy()
                
                # Convert to stereo if needed
                if stem_audio.shape[0] == 1:
                    stem_audio = np.repeat(stem_audio, 2, axis=0)
                
                output_path = job_dir / f"{stem}.wav"
                sf.write(output_path, stem_audio.T, sample_rate)
                output_files[stem] = str(output_path)
                logger.info(f"Saved {stem} stem to {output_path}")
        
        # Upload to Supabase if available
        supabase_urls = {}
        if supabase_storage:
            try:
                supabase_urls = supabase_storage.upload_stems(job_id, output_files)
                logger.info(f"Uploaded stems to Supabase for job {job_id}")
            except Exception as e:
                logger.error(f"Failed to upload to Supabase: {e}")
                # Continue without Supabase upload
        
        return {
            "job_id": job_id,
            "status": "completed",
            "output_files": output_files,
            "supabase_urls": supabase_urls,
            "stems": stems
        }
        
    except Exception as e:
        logger.error(f"Error during stem separation: {e}")
        raise HTTPException(status_code=500, detail=f"Stem separation failed: {str(e)}")

@app.get("/")
async def root():
    """Health check endpoint"""
    return {
        "message": "STEMI Separation Service",
        "status": "running",
        "device": str(device),
        "model_loaded": model is not None
    }

@app.get("/health")
async def health_check():
    """Detailed health check"""
    return {
        "status": "healthy",
        "device": str(device),
        "cuda_available": torch.cuda.is_available(),
        "model_loaded": model is not None,
        "gpu_memory": torch.cuda.get_device_properties(0).total_memory if torch.cuda.is_available() else None
    }

@app.post("/separate")
async def separate_audio(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    stems: Optional[str] = None
):
    """
    Upload an audio file and separate it into stems
    """
    try:
        # Validate file type
        if not file.content_type.startswith("audio/"):
            raise HTTPException(status_code=400, detail="File must be an audio file")
        
        # Parse stems parameter
        stem_list = None
        if stems:
            stem_list = [s.strip() for s in stems.split(",")]
        
        # Save uploaded file
        file_id = str(uuid.uuid4())
        file_path = UPLOAD_DIR / f"{file_id}_{file.filename}"
        
        with open(file_path, "wb") as buffer:
            content = await file.read()
            buffer.write(content)
        
        logger.info(f"File uploaded: {file_path}")
        
        # Perform stem separation
        result = separate_stems(str(file_path), stem_list)
        
        # Clean up uploaded file
        os.remove(file_path)
        
        return result
        
    except Exception as e:
        import traceback
        error_msg = f"Error in separate_audio: {str(e)}"
        logger.error(error_msg)
        logger.error(f"Traceback: {traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=error_msg)

@app.get("/download/{job_id}/{stem}")
async def download_stem(job_id: str, stem: str):
    """
    Download a specific stem from a completed separation job
    """
    stem_file = OUTPUT_DIR / job_id / f"{stem}.wav"
    
    if not stem_file.exists():
        raise HTTPException(status_code=404, detail="Stem file not found")
    
    return FileResponse(
        path=str(stem_file),
        filename=f"{stem}.wav",
        media_type="audio/wav"
    )

@app.get("/jobs/{job_id}")
async def get_job_status(job_id: str):
    """
    Get the status and available stems for a job
    """
    job_dir = OUTPUT_DIR / job_id
    
    if not job_dir.exists():
        raise HTTPException(status_code=404, detail="Job not found")
    
    # List available stems
    stem_files = list(job_dir.glob("*.wav"))
    available_stems = [f.stem for f in stem_files]
    
    # Get Supabase URLs if available
    supabase_urls = {}
    if supabase_storage:
        try:
            supabase_urls = supabase_storage.get_stem_urls(job_id)
        except Exception as e:
            logger.warning(f"Failed to get Supabase URLs: {e}")
    
    return {
        "job_id": job_id,
        "status": "completed",
        "available_stems": available_stems,
        "download_urls": {
            stem: f"/download/{job_id}/{stem}" 
            for stem in available_stems
        },
        "supabase_urls": supabase_urls
    }

@app.delete("/jobs/{job_id}")
async def delete_job(job_id: str):
    """
    Delete a job and its output files
    """
    job_dir = OUTPUT_DIR / job_id
    
    if not job_dir.exists():
        raise HTTPException(status_code=404, detail="Job not found")
    
    # Remove all files in the job directory
    for file in job_dir.glob("*"):
        file.unlink()
    
    # Remove the directory
    job_dir.rmdir()
    
    # Clean up Supabase storage
    if supabase_storage:
        try:
            supabase_storage.delete_stems(job_id)
            logger.info(f"Deleted Supabase stems for job {job_id}")
        except Exception as e:
            logger.warning(f"Failed to delete Supabase stems: {e}")
    
    return {"message": f"Job {job_id} deleted successfully"}

if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get("PORT", 8000))
    uvicorn.run(app, host="0.0.0.0", port=port)
